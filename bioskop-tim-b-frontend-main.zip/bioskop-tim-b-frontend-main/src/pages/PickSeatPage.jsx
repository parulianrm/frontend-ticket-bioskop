import { Container } from 'react-bootstrap';
import PickSeat from '../components/pick-seat/PickSeat';
import { useEffect } from 'react';

export default function PickSeatPage() {
  return (
    <Container>
      <PickSeat />
    </Container>
  );
}
